
#include "example-raw-data-registers.h"

/* InvenSense utils */
//#include "../Invn/EmbUtils/Message.h"
#include "../Invn/EmbUtils/ErrorHelper.h"
//#include "../Invn/EmbUtils/RingBuffer.h"
#include "delay.h"
#include "sys.h"
#include "usart.h" 
#include "icm42688.h"
#include "myiic.h"
#include "IMU.h"
#include "eeprom.h"
#include "spi.h"


/*
 * Set power mode flag
 * Set this flag to run example in low-noise mode.
 * Reset this flag to run example in low-power mode.
 * Note : low-noise mode is not available with sensor data frequencies less than 12.5Hz.
 */
#define IS_LOW_NOISE_MODE 1

/* 
 * Set this to 0 if you want to test timestamping mechanism without CLKIN 32k capability.
 * Please set a hardware bridge between PA17 (from MCU) and CLKIN pins (to ICM).
 * Warning: This option is not available for all ICM426XX. Please check the datasheet.
 */
#define USE_CLK_IN 0


// ģʽѡ����Ҫ��icm42688.h��ѡ��궨��ICM_USE_HARD_SPI/ICM_USE_I2C

// VCC--------5V����3.3V������
//SPI ģʽ����
// PA2------------------------CS
// PB13------------------------SCLK
// PB14------------------------MISO
// PB15------------------------MOSI

//IIC ģʽ����
// PB6------------------------SCL
// PB7------------------------SDA
// AD0Ĭ���������Բ���
int16_t motion6[7];
float ypr[3];          // �ϴ�yaw pitch roll��ֵ
int math_pl=0;

/* Flag set from icm426xx device irq handler */
static volatile int irq_from_device;

static void SetupMCUHardware(struct inv_icm426xx_serif *icm_serif);

static void check_rc(int rc, const char *msg_context)
{
	if (rc < 0) {
		printf("%s: error %d (%s)\r\n", msg_context, rc, inv_error_str(rc));
		while (1)
			;
	}
}

int main(void)
{
	int                       rc = 0;
	struct inv_icm426xx_serif icm426xx_serif;
	SystemInit();
	delay_init();	    	 //��ʱ������ʼ��	  
	uart_init(115200);	 	//���ڳ�ʼ��Ϊ115200
	printf("OK\r\n");
	IIC_Init();
	SPI2_Init();
	//SPI2_SetSpeed(SPI_BaudRatePrescaler_16);
	//delay_ms(100);
	
	//load_config();
	//delay_ms(50);
	//IMU_init();
	/* Initialize MCU hardware */
	SetupMCUHardware(&icm426xx_serif);

	/* Initialize Icm426xx */
	rc = SetupInvDevice(&icm426xx_serif);
	check_rc(rc, "error while setting up INV device");
	
	/* Configure Icm426xx */
	/* /!\ In this example, the data output frequency will be the faster  between Accel and Gyro odr */
	rc = ConfigureInvDevice((uint8_t)IS_LOW_NOISE_MODE, ICM426XX_ACCEL_CONFIG0_FS_SEL_4g,
	                        ICM426XX_GYRO_CONFIG0_FS_SEL_2000dps, ICM426XX_ACCEL_CONFIG0_ODR_200_HZ,
	                        ICM426XX_GYRO_CONFIG0_ODR_200_HZ, (uint8_t)USE_CLK_IN);

	check_rc(rc, "error while configuring INV device");
	delay_ms(100);
	do {
		/* Poll device for data */
		//if (irq_from_device & TO_MASK(INV_GPIO_INT1)) {
			rc = GetDataFromInvDevice();
			check_rc(rc, "error while processing FIFO");

			__disable_irq();
			//irq_from_device &= ~TO_MASK(INV_GPIO_INT1);
			__enable_irq();
		//}
	delay_ms(10);
	} while (1);
//	while(1)
//	{	
//		IMU_getYawPitchRoll(ypr);
//		IMU_TT_getgyro(motion6);
//		
//		math_pl++;
//		delay_ms(10);
//	}
}


static uint8_t io_write_reg(uint8_t reg, uint8_t value)
{
#if defined(ICM_USE_HARD_SPI)
    SPI_IMU_CS=0;
    /* д��Ҫ���ļĴ�����ַ */
    /* д��Ҫ���ļĴ�����ַ */
    SPI2_ReadWriteByte(reg);
    /* ��ȡ�Ĵ������� */
    SPI2_ReadWriteByte(value);
    SPI_IMU_CS=1;
#elif defined(ICM_USE_I2C)
	IICwriteBytes(ICM42688_ADDRESS, reg, 1, &value);
#endif
    return 0;
}

int inv_io_hal_read_reg(struct inv_icm426xx_serif *serif, uint8_t reg, uint8_t *rbuffer,
                        uint32_t rlen)
{
	uint32_t len = rlen;
#if defined(ICM_USE_HARD_SPI)
    reg |= 0x80;
    SPI_IMU_CS=0;
    /* д��Ҫ���ļĴ�����ַ */
    SPI2_ReadWriteByte(reg);
    /* ��ȡ�Ĵ������� */
    while(len)
	{
		*rbuffer = SPI2_ReadWriteByte(0x00);
		len--;
		rbuffer++;
	}
    SPI_IMU_CS=1;
#elif defined(ICM_USE_I2C)
	IICreadBytes(ICM42688_ADDRESS, reg, len, buf);
#endif

		return 0;
}

int inv_io_hal_write_reg(struct inv_icm426xx_serif *serif, uint8_t reg, const uint8_t *wbuffer,
                         uint32_t wlen)
{
	int rc;

	for (uint32_t i = 0; i < wlen; i++) 
	{
		rc = io_write_reg(reg + i, wbuffer[i]);
		if (rc)
			return rc;
	}
	return 0;
}


/* --------------------------------------------------------------------------------------
 *  Functions definitions
 * -------------------------------------------------------------------------------------- */

/*
 * This function initializes MCU on which this software is running.
 * It configures:
 *   - a UART link used to print some messages
 *   - interrupt priority group and GPIO so that MCU can receive interrupts from ICM426xx
 *   - a microsecond timer requested by Icm426xx driver to compute some delay
 *   - a microsecond timer used to get some timestamps
 *   - a serial link to communicate from MCU to Icm426xx
 */
static void SetupMCUHardware(struct inv_icm426xx_serif *icm_serif)
{

	/* Initialize serial inteface between MCU and Icm426xx */
	icm_serif->context    = 0; /* no need */
	icm_serif->read_reg   = inv_io_hal_read_reg;
	icm_serif->write_reg  = inv_io_hal_write_reg;
	icm_serif->max_read   = 1024 * 3; /* maximum number of bytes allowed per serial read */
	icm_serif->max_write  = 1024 * 3; /* maximum number of bytes allowed per serial write */
	icm_serif->serif_type = 0;
	//inv_io_hal_init(icm_serif);
}
void inv_icm426xx_sleep_us(uint32_t us)
{
	delay_us(us);
}

uint64_t inv_icm426xx_get_time_us(void)
{
	return 0;
}


